
import cv2
import time
from collections import Counter
from ultralytics import YOLO


MODEL_NAME = "yolov8s.pt"  
CAMERA_INDEX = 0
CONFIDENCE_THRESHOLD = 0.35
OUTPUT_FILE = "live_detection_output.mp4"


def main():
    print("Loading YOLOv8 Small model...")
    model = YOLO(MODEL_NAME)

    print("Opening webcam...")
    cap = cv2.VideoCapture(CAMERA_INDEX)

    if not cap.isOpened():
        print("ERROR: Cannot open webcam.")
        print("Check camera permissions or try CAMERA_INDEX = 1.")
        return

   
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

   
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps_camera = cap.get(cv2.CAP_PROP_FPS)

    if not fps_camera or fps_camera < 1 or fps_camera > 120:
        fps_camera = 20.0

    
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    writer = cv2.VideoWriter(
        OUTPUT_FILE, fourcc, fps_camera, (width, height)
    )

    if not writer.isOpened():
        print("ERROR: Could not create video file.")
        cap.release()
        return

    print("Detection running. Press Q to stop.")
    print(f"Video will be saved as: {OUTPUT_FILE}")

    previous_time = time.time()

    try:
        while True:
            success, frame = cap.read()

            if not success:
                print("Could not read webcam frame.")
                break

            results = model.predict(
                source=frame,
                conf=CONFIDENCE_THRESHOLD,
                imgsz=640,
                verbose=False
            )

            result = results[0]

            
            annotated_frame = result.plot()

            
            counts = Counter()

            if result.boxes is not None:
                for box in result.boxes:
                    class_id = int(box.cls[0].item())
                    class_name = model.names[class_id]
                    counts[class_name] += 1

           
            current_time = time.time()
            elapsed = current_time - previous_time
            fps = 1.0 / elapsed if elapsed > 0 else 0.0
            previous_time = current_time

            
            total_objects = sum(counts.values())

            cv2.rectangle(
                annotated_frame, (10, 10), (360, 100),
                (0, 0, 0), -1
            )

            cv2.putText(
                annotated_frame,
                f"Objects detected: {total_objects}",
                (20, 38),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7, (0, 255, 0), 2
            )

            cv2.putText(
                annotated_frame,
                f"FPS: {fps:.1f}",
                (20, 68),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65, (255, 255, 255), 2
            )

           
            y_position = 130
            for name, count in counts.most_common(5):
                cv2.putText(
                    annotated_frame,
                    f"{name}: {count}",
                    (20, y_position),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.6, (0, 255, 255), 2
                )
                y_position += 25

            
            writer.write(annotated_frame)

           
            cv2.imshow(
                "YOLOv8 Small - Live Object Detection",
                annotated_frame
            )

           
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break

    finally:
        cap.release()
        writer.release()
        cv2.destroyAllWindows()
        print(f"Recording saved to: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
